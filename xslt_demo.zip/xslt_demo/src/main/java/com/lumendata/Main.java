package com.lumendata;

import javax.xml.transform.*;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import java.io.File;

public class Main {

    public static void main(String[] args) throws TransformerException {
        File inputFile = new File("src/main/resources/input.xml");
        File xsltFile = new File("src/main/resources/transform.xslt");

        File outputFile = new File("output.xml");

        TransformerFactory transformerFactory = TransformerFactory.newInstance();

        Transformer transformer = transformerFactory.newTransformer(new StreamSource(xsltFile));

        transformer.transform(new StreamSource(inputFile), new StreamResult(outputFile));

        System.out.println("Transformation completed." + outputFile.getAbsolutePath());
    }
}
